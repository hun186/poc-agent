# api/services/auth_store.py
from __future__ import annotations

import secrets
from threading import RLock
from typing import Any

from .auth_json_store import JsonFileStore
from .auth_login_audit_store import LoginAuditStore
from .auth_password_flows import AuthPasswordMixin
from .auth_passwords import DUMMY_PASSWORD_HASH, _hash_password, _validate_password, _verify_password
from .auth_support import (
    AUTH_THROTTLE_BLOCK_SECONDS,
    AUTH_THROTTLE_FAILURE_LIMIT,
    AUTH_THROTTLE_WINDOW_SECONDS,
    LEGACY_ROLE_ALIASES,
    LOGIN_AUDIT_LIMIT,
    ROLE_DATA_EDITOR,
    ROLE_DATA_READER,
    ROLE_DB_OPERATOR,
    ROLE_SUPERUSER,
    VALID_ROLES,
    AuthUser,
    _auth_file,
    _b64url,
    _b64url_decode,
    _load_bootstrap_superusers,
    _login_audit_file,
    _now_ts,
    _normalize_throttle_part,
    _throttle_key,
    _token_secret,
    _token_ttl_seconds,
    _utc_now,
    has_role_at_least,
    normalize_role,
    public_role_options,
)


class AuthStore(AuthPasswordMixin):
    def __init__(self) -> None:
        self._lock = RLock()
        self._throttle_lock = RLock()
        self._auth_failures: dict[str, dict[str, int]] = {}
        self.path = _auth_file()
        self._json_store = JsonFileStore()
        self.login_audit = LoginAuditStore(_login_audit_file(), self.path, self._json_store)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_file()
        self.login_audit.ensure()
        self.ensure_bootstrap_superusers()

    def _ensure_file(self) -> None:
        if self.path.exists():
            return
        self._write(self._normalize_data({"users": {}, "created_at": _utc_now(), "updated_at": _utc_now()}))

    def _normalize_data(self, data: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(data.get("users"), dict):
            data["users"] = {}
        if not isinstance(data.get("token_denylist"), dict):
            data["token_denylist"] = {}
        if not isinstance(data.get("password_reset_tokens"), dict):
            data["password_reset_tokens"] = {}
        data.pop("login_audit", None)
        return data

    def _json_read(self, path, default: dict[str, Any]) -> dict[str, Any]:
        return self._json_store.read(path, default)

    def _json_write(self, path, data: dict[str, Any], *, prefix: str) -> None:
        self._json_store.write(path, data, prefix=prefix)

    def _read(self) -> dict[str, Any]:
        with self._lock:
            data = self._json_read(self.path, {"users": {}})
            return self._normalize_data(data)

    def _write(self, data: dict[str, Any]) -> None:
        with self._lock:
            data = self._normalize_data(data)
            self._json_write(self.path, data, prefix=".auth_users.")

    def _prune_token_denylist(self, data: dict[str, Any]) -> bool:
        now = _now_ts()
        denylist = data.setdefault("token_denylist", {})
        removed = False
        for jti, item in list(denylist.items()):
            if not isinstance(item, dict) or int(item.get("expires_at") or 0) < now:
                denylist.pop(jti, None)
                removed = True
        return removed

    @staticmethod
    def _invalidate_user_tokens(user: dict[str, Any]) -> None:
        user["token_version"] = int(user.get("token_version") or 0) + 1
        user["tokens_invalidated_at"] = _utc_now()

    def ensure_bootstrap_superusers(self) -> None:
        bootstrap_users = _load_bootstrap_superusers()
        if not bootstrap_users:
            return
        data = self._read()
        changed = self._prune_token_denylist(data)
        users = data.setdefault("users", {})
        for item in bootstrap_users:
            username = item["username"]
            password = item["password"]
            existing = users.get(username)
            if not isinstance(existing, dict):
                users[username] = {
                    "username": username,
                    "password_hash": _hash_password(password),
                    "role": "superuser",
                    "status": "active",
                    "token_version": 0,
                    "created_at": _utc_now(),
                    "approved_at": _utc_now(),
                    "approved_by": "bootstrap",
                }
                changed = True
            else:
                if not _verify_password(password, str(existing.get("password_hash") or "")):
                    existing["password_hash"] = _hash_password(password)
                    self._invalidate_user_tokens(existing)
                    changed = True
                if existing.get("role") != "superuser" or existing.get("status") != "active":
                    existing["role"] = "superuser"
                    existing["status"] = "active"
                    existing["approved_at"] = _utc_now()
                    existing["approved_by"] = "bootstrap"
                    changed = True
                if "token_version" not in existing:
                    existing["token_version"] = 0
                    changed = True
        if changed:
            self._write(data)


    def ensure_mock_preview_user(self) -> AuthUser:
        username = "vercel_mock_reader"
        data = self._read()
        users = data.setdefault("users", {})
        existing = users.get(username)
        changed = False
        if not isinstance(existing, dict):
            users[username] = {
                "username": username,
                "password_hash": _hash_password("disabled-" + secrets.token_urlsafe(32)),
                "role": ROLE_DATA_READER,
                "status": "active",
                "token_version": 0,
                "created_at": _utc_now(),
                "approved_at": _utc_now(),
                "approved_by": "vercel_mock_preview",
                "full_name": "Vercel Mock Reader Preview",
                "department": "preview",
                "note": "Process-local mock preview account; no password login.",
            }
            changed = True
        else:
            if existing.get("role") != ROLE_DATA_READER or existing.get("status") != "active":
                existing["role"] = ROLE_DATA_READER
                existing["status"] = "active"
                existing["approved_at"] = _utc_now()
                existing["approved_by"] = "vercel_mock_preview"
                changed = True
            if "token_version" not in existing:
                existing["token_version"] = 0
                changed = True
        if changed:
            self._write(data)
        return AuthUser(username=username, role=ROLE_DATA_READER, status="active", mock_preview=True)

    def register(self, username: str, password: str, *, full_name: str | None = None, department: str | None = None, note: str | None = None) -> dict[str, Any]:
        username = username.strip()
        if not username or len(username) > 64:
            raise ValueError("帳號不可為空，且長度需小於 64。")
        _validate_password(password)
        data = self._read()
        users = data.setdefault("users", {})
        if username in users:
            raise ValueError("帳號已存在。")
        users[username] = {
            "username": username,
            "password_hash": _hash_password(password),
            "role": ROLE_DATA_READER,
            "status": "pending",
            "token_version": 0,
            "created_at": _utc_now(),
            "approved_at": None,
            "approved_by": None,
            "full_name": (full_name or "").strip() or None,
            "department": (department or "").strip() or None,
            "note": (note or "").strip() or None,
        }
        self._write(data)
        return self.public_user(users[username])

    def authenticate(self, username: str, password: str) -> AuthUser | None:
        data = self._read()
        user = data.get("users", {}).get(username)
        password_hash = str(user.get("password_hash") or DUMMY_PASSWORD_HASH) if isinstance(user, dict) else DUMMY_PASSWORD_HASH
        password_ok = _verify_password(password, password_hash)
        if not isinstance(user, dict) or not password_ok:
            return None
        if user.get("status") != "active":
            return AuthUser(username=username, role=normalize_role(str(user.get("role") or "")), status=str(user.get("status") or "pending"))
        return AuthUser(username=username, role=normalize_role(str(user.get("role") or "")), status="active")

    def get_user(self, username: str) -> dict[str, Any] | None:
        user = self._read().get("users", {}).get(username)
        return user if isinstance(user, dict) else None

    def list_users(self) -> list[dict[str, Any]]:
        users = self._read().get("users", {})
        return [self.public_user(user) for user in users.values() if isinstance(user, dict)]

    def approve_user(self, username: str, role: str, approved_by: str) -> dict[str, Any]:
        requested_role = (role or "").strip().lower()
        if requested_role not in VALID_ROLES and requested_role not in LEGACY_ROLE_ALIASES:
            raise ValueError("role 必須是 superuser、db_operator、data_editor 或 data_reader。")
        role = normalize_role(requested_role)
        data = self._read()
        user = data.get("users", {}).get(username)
        if not isinstance(user, dict):
            raise KeyError("帳號不存在。")
        user["role"] = role
        user["status"] = "active"
        user["approved_at"] = _utc_now()
        user["approved_by"] = approved_by
        self._write(data)
        return self.public_user(user)

    def reject_user(self, username: str, rejected_by: str) -> dict[str, Any]:
        data = self._read()
        user = data.get("users", {}).get(username)
        if not isinstance(user, dict):
            raise KeyError("帳號不存在。")
        user["status"] = "rejected"
        user["rejected_at"] = _utc_now()
        user["rejected_by"] = rejected_by
        self._invalidate_user_tokens(user)
        self._write(data)
        return self.public_user(user)

    def delete_user(self, username: str) -> dict[str, Any]:
        data = self._read()
        users = data.get("users", {})
        user = users.get(username)
        if not isinstance(user, dict):
            raise KeyError("帳號不存在。")
        removed = dict(user)
        del users[username]
        self._write(data)
        return self.public_user(removed)

    def deny_token(self, payload: dict[str, Any]) -> None:
        jti = str(payload.get("jti") or "")
        if not jti:
            return
        data = self._read()
        self._prune_token_denylist(data)
        data.setdefault("token_denylist", {})[jti] = {
            "username": str(payload.get("sub") or ""),
            "denied_at": _utc_now(),
            "expires_at": int(payload.get("exp") or _now_ts()),
        }
        self._write(data)

    def is_token_denied(self, jti: str) -> bool:
        if not jti:
            return True
        data = self._read()
        changed = self._prune_token_denylist(data)
        item = data.get("token_denylist", {}).get(jti)
        if changed:
            self._write(data)
        return isinstance(item, dict)

    def is_token_current(self, username: str, token_version: int) -> bool:
        user = self.get_user(username)
        if not isinstance(user, dict):
            return False
        return int(user.get("token_version") or 0) == token_version

    def record_login_audit(self, username: str, *, success: bool, reason: str, role: str | None = None, status_value: str | None = None, client_host: str | None = None, user_agent: str | None = None) -> None:
        with self._lock:
            self.login_audit.record(
                username,
                success=success,
                reason=reason,
                role=role,
                status_value=status_value,
                client_host=client_host,
                user_agent=user_agent,
            )

    def list_login_audit(self, limit: int = 100) -> list[dict[str, Any]]:
        return self.login_audit.list(limit)

    def throttle_retry_after(self, scope: str, username: str | None, client_host: str | None = None) -> int:
        key = _throttle_key(scope, username, client_host)
        now = _now_ts()
        with self._throttle_lock:
            state = self._auth_failures.get(key)
            if not state:
                return 0
            blocked_until = int(state.get("blocked_until") or 0)
            if blocked_until <= now:
                if int(state.get("first_failed_at") or 0) + AUTH_THROTTLE_WINDOW_SECONDS <= now:
                    self._auth_failures.pop(key, None)
                return 0
            return blocked_until - now

    def record_auth_failure(self, scope: str, username: str | None, client_host: str | None = None) -> int:
        key = _throttle_key(scope, username, client_host)
        now = _now_ts()
        with self._throttle_lock:
            state = self._auth_failures.get(key)
            if not state or int(state.get("first_failed_at") or 0) + AUTH_THROTTLE_WINDOW_SECONDS <= now:
                state = {"first_failed_at": now, "failures": 0, "blocked_until": 0}
                self._auth_failures[key] = state
            state["failures"] = int(state.get("failures") or 0) + 1
            if state["failures"] >= AUTH_THROTTLE_FAILURE_LIMIT:
                state["blocked_until"] = now + AUTH_THROTTLE_BLOCK_SECONDS
                return AUTH_THROTTLE_BLOCK_SECONDS
            return 0

    def clear_auth_failures(self, scope: str, username: str | None, client_host: str | None = None) -> None:
        key = _throttle_key(scope, username, client_host)
        with self._throttle_lock:
            self._auth_failures.pop(key, None)

    def clear_auth_failures_for_user(self, scope: str, username: str) -> int:
        """Clear all in-memory throttle records for a user across client hosts."""
        prefix = f"{scope}:{_normalize_throttle_part(username)}:"
        with self._throttle_lock:
            keys = [key for key in self._auth_failures if key.startswith(prefix)]
            for key in keys:
                self._auth_failures.pop(key, None)
            return len(keys)

    @staticmethod
    def public_user(user: dict[str, Any]) -> dict[str, Any]:
        public = {k: v for k, v in user.items() if k != "password_hash"}
        public["role"] = normalize_role(str(public.get("role") or ""))
        return public


from .auth_tokens import parse_token as parse_token
from .auth_tokens import create_token as _create_token


def create_token(user: AuthUser) -> str:
    return _create_token(user, AUTH_STORE.get_user)


AUTH_STORE = AuthStore()
